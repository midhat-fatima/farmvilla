<?php
/*
 * this is just to explain PRO features
 */

?>

<h2><?php _e('Get PRO Version for More Features', 'wooh'); ?></h2>
<ul style="margin-left:20px; list-style-type: square !important;">
	<li><?php _e('Shop page', 'wooh'); ?></li>
	<li><?php _e('Product page', 'wooh'); ?></li>
	<li><span style="line-height: 13px;"><?php _e('Cart page', 'wooh'); ?></span></li>
	<li><?php _e('Checkout page', 'wooh'); ?></li>
	<li><?php _e('My Account page', 'wooh'); ?></li>
	<li><?php _e('Email template', 'wooh'); ?></li>
	<li><?php _e('Product Tabs', 'wooh'); ?></li>
	<li><?php _e('Enquiry From', 'wooh'); ?></li>
	<li><?php _e('Redirect after add to cart URL', 'wooh'); ?></li>
</ul>

<a class="button" href="https://najeebmedia.com/wordpress-plugin/woocommerce-customizer/"><?php _e('More Detail', 'wooh'); ?></a>