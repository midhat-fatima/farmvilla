<?php
/*
 * this is just to explain PRO features
 */

?>

<h2><?php _e('Best Woocommerce Plugin to Add Fields on Product Page', 'wooh'); ?></h2>
<ul style="margin-left:20px; list-style-type: square !important;">
	<li><?php _e('21 Types Inputs', 'wooh'); ?></li>
	<li><?php _e('File/Image Upload', 'wooh'); ?></li>
	<li><?php _e('Options with Prices', 'wooh'); ?></li>
	<li><?php _e('Conditional Logic', 'wooh'); ?></li>
	<li><?php _e('Field Privacy Control', 'wooh'); ?></li>
	<li><?php _e('Responsive Design', 'wooh'); ?></li>
	<li><?php _e('Price Matrix, Discount', 'wooh'); ?></li>
	<li><?php _e('Much More', 'wooh'); ?></li>
</ul>

<a class="button" href="http://ppom.nmediahosting.com/"><?php _e('Demos', 'wooh'); ?></a>
<a class="button" href="https://najeebmedia.com/wordpress-plugin/woocommerce-personalized-product-option/"><?php _e('More Detail', 'wooh'); ?></a>
<a class="button" href="https://najeebmedia.com/2018/01/02/woocommerce-personalized-product-options-manager-inputs-guide/"><?php _e('Fields Types with Demos', 'wooh'); ?></a>